﻿using System.Collections;
using System.Drawing;
using System.Reflection;
using Outsystems.Colors.Structures;
using OutSystems.ExternalLibraries.SDK;

namespace OutSystems.Colors
{
    public class CssColors : IColors
    {
        public void ConvertColorNameToHex(string colorName, out string hexaCode, out string errorMessage)
        {
            hexaCode = "";
            errorMessage = "";

            try
            {
                Color colorValue = Color.FromName(colorName);
                hexaCode = $"#{colorValue.R:X2}{colorValue.G:X2}{colorValue.B:X2}";
            }
            catch (Exception e)
            {
               errorMessage = e.ToString();
            }
        }

        public void FindNearestWebColor(string hexColorCode, out string nearestHexColorCode, out string errorMessage)
        {
           nearestHexColorCode = "";
           errorMessage = "";

            Color targetColor = ColorTranslator.FromHtml(hexColorCode);
            ArrayList colorsSet = GetWebColorsSet();

            double dblInputRed = Convert.ToDouble(targetColor.R);
            double dblInputGreen = Convert.ToDouble(targetColor.G);
            double dblInputBlue = Convert.ToDouble(targetColor.B);

            double distance = 500.0;
            double temp;

            Color nearestColor = Color.Empty;

            try
            {
                foreach (object obj in colorsSet)
                {
                    double dblTestRed = Math.Pow(Convert.ToDouble(((Color)obj).R) - dblInputRed, 2.0);
                    double dblTestGreen = Math.Pow(Convert.ToDouble(((Color)obj).G) - dblInputGreen, 2.0);
                    double dblTestBlue = Math.Pow(Convert.ToDouble(((Color)obj).B) - dblInputBlue, 2.0);
                    temp = Math.Sqrt(dblTestBlue + dblTestGreen + dblTestRed);

                    if (temp < distance)
                    {
                        distance = temp;
                        nearestColor = (Color)obj;
                    }
                }

               nearestHexColorCode = ColorTranslator.ToHtml(nearestColor);
            }
            catch (Exception e)
            {
               errorMessage = e.ToString();
            }
        }

        public void FindNearestColor(List<HexaCode> hexaCodesList, string hexColorCode, out string nearestHexColorCode, out string errorMessage)
        {
           nearestHexColorCode = "";
           errorMessage = "";

            Color targetColor = ColorTranslator.FromHtml(hexColorCode);
            ArrayList colorsSet = TransformRecordListToArrayList(hexaCodesList);

            double dblInputRed = Convert.ToDouble(targetColor.R);
            double dblInputGreen = Convert.ToDouble(targetColor.G);
            double dblInputBlue = Convert.ToDouble(targetColor.B);

            double distance = 500.0;
            double temp;

            Color nearestColor = Color.Empty;

            try
            {
                foreach (object obj in colorsSet)
                {
                    double dblTestRed = Math.Pow(Convert.ToDouble(((Color)obj).R) - dblInputRed, 2.0);
                    double dblTestGreen = Math.Pow(Convert.ToDouble(((Color)obj).G) - dblInputGreen, 2.0);
                    double dblTestBlue = Math.Pow(Convert.ToDouble(((Color)obj).B) - dblInputBlue, 2.0);
                    temp = Math.Sqrt(dblTestBlue + dblTestGreen + dblTestRed);

                    if (temp < distance)
                    {
                        distance = temp;
                        nearestColor = (Color)obj;
                    }
                }

               nearestHexColorCode = ColorTranslator.ToHtml(nearestColor);
            }
            catch (Exception e)
            {
               errorMessage = e.ToString();
            }
        }

        static ArrayList TransformRecordListToArrayList(List<HexaCode> hexaCodesList)
        {
            var colors = new ArrayList();

            foreach (var hexaRec in hexaCodesList)
            {
                var c = ColorTranslator.FromHtml(hexaRec.Code);
                colors.Add(c);
            }
            return colors;
        }

        static ArrayList GetWebColorsSet()
        {
            var colorType = typeof(Color);
            var propertyInfos = colorType.GetProperties(BindingFlags.Public | BindingFlags.Static);
            var colors = new ArrayList();
            foreach (var pi in propertyInfos)
            {
                if (pi.PropertyType.Equals(typeof(Color)))
                {
                    var value = pi.GetValue(null);
                    if (value is Color color)
                    {
                        colors.Add(color);
                    }
                }
            }
            return colors;
        }
    }
}
