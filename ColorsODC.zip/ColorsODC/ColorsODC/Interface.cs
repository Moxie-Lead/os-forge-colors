﻿using Outsystems.Colors.Structures;
using OutSystems.ExternalLibraries.SDK;

namespace OutSystems.Colors
{
    [OSInterface(
        Description = "Extension with methods to deal with colors.",
        IconResourceName = "Outsystems.Colors.resources.icon.png",
        Name = "Colors"
    )]
    public interface IColors
    {
        [OSAction(
            Description = "Method to convert an inputted color name to the corresponding hexadecimal representation.",
            IconResourceName = "Outsystems.Colors.resources.icon.png")]
        void ConvertColorNameToHex(
            [OSParameter(
                Description = "Color name to which we want to get the hexadecimal representation.")]
            string colorName,
            [OSParameter(
                Description = "Hexadecimal color code found.")]
            out string hexaCode,
            [OSParameter(
                Description = "Error message, if any occurs.")]
            out string errorMessage);

        [OSAction(
            Description = "Method to find the nearest Web color from the inputted color code, using the Euclidean Distance between Two Colors.",
            IconResourceName = "Outsystems.Colors.resources.icon.png")]
        void FindNearestWebColor(
            [OSParameter(
                Description = "Hexadecimal color code for which we will find the nearest color.")]
            string hexColorCode,
            [OSParameter(
                Description = "Hexadecimal color code for the nearest color found.")]
            out string nearestHexColorCode,
            [OSParameter(
                Description = "Error message, if any occurs.")]
            out string errorMessage);

        [OSAction(
            Description = "Method to find the nearest color from the inputted color code and set of colors given, using the Euclidean Distance between Two Colors.",
            IconResourceName = "Outsystems.Colors.resources.icon.png")]
        void FindNearestColor(
            [OSParameter(
                Description = "List of hexadecimal color codes.")]
            List<HexaCode> hexaCodesList,
            [OSParameter(
                Description = "Hexadecimal color code for which we will find the nearest color.")]
            string hexColorCode,
            [OSParameter(
                Description = "Hexadecimal color code for the nearest color found.")]
            out string nearestHexColorCode,
            [OSParameter(
                Description = "Error message, if any occurs.")]
            out string errorMessage);
    }
}