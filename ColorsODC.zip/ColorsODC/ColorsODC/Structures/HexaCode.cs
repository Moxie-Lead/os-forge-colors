﻿using OutSystems.ExternalLibraries.SDK;

namespace Outsystems.Colors.Structures;

[OSStructure(
    Description = "Structure to bind a hexadecimal color code.")]
public struct HexaCode
{
    [OSStructureField(
        Description = "Text with the hexadecimal code.",
        Length = 7,
        IsMandatory = true)]
    public string Code;
}